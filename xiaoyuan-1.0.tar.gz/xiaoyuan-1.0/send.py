def sends():
	print("发送信息")
