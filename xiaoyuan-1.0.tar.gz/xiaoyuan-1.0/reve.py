def revers():
	print("收到信息")
